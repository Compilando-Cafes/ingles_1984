﻿=== Eye Cursor Set ===

By: katydidz (http://www.rw-designer.com/user/101268) hollyberryrocks@gmail.com

Download: http://www.rw-designer.com/cursor-set/eye-1

Author's description:

A set of blinking eye cursors.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.